@echo off
rem Startet LockedIn Body: richtet beim ersten Mal Python ein und oeffnet die App im Browser.
cd /d "%~dp0backend"
where python >nul 2>nul || (echo Python fehlt. Installieren: https://www.python.org/downloads/ & pause & exit /b 1)
if not exist .env (
  copy .env.example .env >nul
  echo.
  echo   Datei backend\.env angelegt. Oeffne sie und trag deinen Gemini-API-Key ein ^(GEMINI_API_KEY=...^).
  echo   Die App startet trotzdem, nur die KI-Funktionen sind bis dahin aus.
  echo.
)
if not exist .venv python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install -q -r requirements.txt
python main.py
pause
