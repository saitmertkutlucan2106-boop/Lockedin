#!/usr/bin/env bash
# Startet LockedIn Body: richtet beim ersten Mal Python ein und öffnet die App im Browser.
set -e
cd "$(dirname "$0")/backend"
if [ ! -f .env ]; then
  cp .env.example .env
  echo
  echo "  Datei backend/.env angelegt. Öffne sie und trag deinen Gemini-API-Key ein (GEMINI_API_KEY=...)."
  echo "  Die App startet trotzdem, nur die KI-Funktionen sind bis dahin aus."
  echo
fi
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
python -m pip install -q -r requirements.txt
python main.py
