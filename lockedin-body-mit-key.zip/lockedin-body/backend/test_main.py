"""Tests fürs Backend mit einer gefälschten Gemini-API. Start: python -m pytest -q
Du brauchst dafür keinen echten Key und kein Internet."""
import json

import httpx
import pytest
from fastapi.testclient import TestClient

import main

client = TestClient(main.app, base_url="http://localhost")
STATE = {"verdict": "Pause", "readiness": 20, "fitness": 40, "fatigue": 60, "penalties": {"sleep": 30}, "has_checkin": True, "drivers": ["wenig Schlaf"]}
KEY = "test-key-123"


def fake_gemini(handler):
    main.transport = httpx.MockTransport(handler)


@pytest.fixture(autouse=True)
def env(monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", KEY)
    yield
    main.transport = None


def answer(obj):
    return httpx.Response(200, json={"candidates": [{"content": {"role": "model", "parts": [{"text": json.dumps(obj)}]}}]})


def test_health_without_key(monkeypatch):
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
    r = client.get("/api/health").json()
    assert not r["key_set"] and not r["key_valid"] and "backend/.env" in r["message"]


def test_health_valid_key_and_model():
    def handler(request):
        assert request.headers["x-goog-api-key"] == KEY and "key=" not in str(request.url)   # Key nie in der URL
        return httpx.Response(200, json={"models": [
            {"name": "models/gemini-3.6-flash", "supportedGenerationMethods": ["generateContent"]},
            {"name": "models/gemini-embedding-2", "supportedGenerationMethods": ["embedContent"]}]})
    fake_gemini(handler)
    r = client.get("/api/health").json()
    assert r["key_valid"] and r["model_available"] and r["models"] == ["gemini-3.6-flash"] and KEY not in json.dumps(r)
    assert not client.get("/api/health?model=gemini-9-ultra").json()["model_available"]


def test_health_rejected_key():
    fake_gemini(lambda request: httpx.Response(400, json={"error": {"code": 400, "message": "API key not valid. Please pass a valid API key."}}))
    r = client.get("/api/health").json()
    assert r["key_set"] and not r["key_valid"] and "abgelehnt" in r["message"]


def test_voice_todo_is_cleaned():
    seen = {}

    def handler(request):
        seen["url"], seen["key"], seen["body"] = str(request.url), request.headers["x-goog-api-key"], json.loads(request.content)
        return answer({"tasks": [
            {"title": "  Mathe-Übungsblatt  ", "minutes": 900, "category_id": "uni", "date": "2026-10-25", "time": "9:30", "effort": 3, "kind": "kopf"},
            {"title": "Joggen", "minutes": "40", "category_id": "gibtsnicht", "date": "quatsch", "time": "19:00", "effort": 7, "kind": "tanzen"},
            {"title": "", "minutes": 5, "category_id": "uni", "date": "", "time": "", "effort": 1, "kind": "alltag"},
        ]})
    fake_gemini(handler)
    r = client.post("/api/voice-todo", json={"transcript": "morgen Mathe und heute abend joggen", "today": "2026-10-24",
                                             "categories": [{"id": "uni", "name": "Uni"}, {"id": "priv", "name": "Privat"}]})
    assert r.status_code == 200
    a, b = r.json()["tasks"]
    assert a == {"t": "Mathe-Übungsblatt", "m": 600, "c": "uni", "d": "2026-10-25", "tm": "09:30", "e": 3, "k": "kopf"}
    assert b == {"t": "Joggen", "m": 40, "c": "uni", "d": "2026-10-24", "tm": "19:00", "e": 3, "k": "alltag"}
    assert seen["url"].endswith("/models/gemini-3.6-flash:generateContent") and seen["key"] == KEY
    cfg = seen["body"]["generationConfig"]
    assert cfg["responseMimeType"] == "application/json" and cfg["responseSchema"]["required"] == ["tasks"]
    assert "Samstag" in seen["body"]["systemInstruction"]["parts"][0]["text"]


def test_missing_key_gives_clear_error(monkeypatch):
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
    r = client.post("/api/voice-todo", json={"transcript": "Wäsche", "today": "2026-10-24"})
    assert r.status_code == 503 and "backend/.env" in r.json()["detail"]


@pytest.mark.parametrize("status,body,code,word", [
    (429, {"error": {"message": "quota"}}, 429, "Limit"),
    (404, {"error": {"message": "not found"}}, 404, "gibt es nicht"),
    (403, {"error": {"message": "API key not valid"}}, 401, "abgelehnt"),
    (500, {"error": {"message": "boom"}}, 502, "überlastet"),
])
def test_errors_are_explained(status, body, code, word):
    fake_gemini(lambda request: httpx.Response(status, json=body))
    r = client.post("/api/voice-todo", json={"transcript": "Wäsche", "today": "2026-10-24"})
    assert r.status_code == code and word in r.json()["detail"]


def test_old_ollama_model_names_fall_back_to_default():
    seen = {}
    fake_gemini(lambda request: (seen.update(url=str(request.url)), answer({"tasks": []}))[1])
    for name in ("gemma4", "gemma4:e2b"):
        client.post("/api/voice-todo", json={"transcript": "x", "today": "2026-10-24", "model": name})
        assert "/models/gemini-3.6-flash:" in seen["url"]


def test_bad_model_name_is_rejected():
    r = client.post("/api/voice-todo", json={"transcript": "x", "today": "2026-10-24", "model": "../../secret"})
    assert r.status_code == 400


def test_evaluate_keeps_score_system_in_charge():
    fake_gemini(lambda request: answer({"results": [
        {"id": "1", "level": 0, "reason": "Heute lieber nicht."},
        {"id": "2", "level": 3, "reason": ""},
    ]}))
    r = client.post("/api/evaluate", json={"state": STATE, "tasks": [
        {"id": "1", "title": "Mails", "minutes": 10, "kind": "alltag", "effort": 1, "rule_level": 3},
        {"id": "2", "title": "Klausur lernen", "minutes": 120, "kind": "kopf", "effort": 3, "rule_level": 0},
        {"id": "3", "title": "Wäsche", "minutes": 5, "kind": "alltag", "effort": 1, "rule_level": 2},
    ]}).json()["results"]
    assert [x["level"] for x in r] == [2, 1, 2]          # höchstens eine Stufe Abweichung
    assert r[1]["reason"] == "Lieber klein anfangen."  # leere Begründung wird ersetzt
    assert r[2]["reason"] == "Machbar."                # fehlende Aufgabe fällt auf die Regel zurück


def test_chat_streams_in_the_format_the_app_expects():
    sse = ('data: {"candidates":[{"content":{"parts":[{"text":"1. Blatt"}]}}]}\n\n'
           'data: {"candidates":[{"content":{"parts":[{"text":" holen"},{"text":"x","thought":true}]}}]}\n\n')
    seen = {}

    def handler(request):
        seen["url"], seen["body"] = str(request.url), json.loads(request.content)
        return httpx.Response(200, content=sse.encode(), headers={"content-type": "text/event-stream"})
    fake_gemini(handler)
    png = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
    r = client.post("/api/chat", json={"model": "gemini-3.6-flash", "stream": True, "messages": [
        {"role": "system", "content": "Du bist Coach."}, {"role": "user", "content": "Hilfe", "images": [png]},
        {"role": "assistant", "content": "Okay"}, {"role": "user", "content": "weiter"}]})
    assert r.status_code == 200
    rows = [json.loads(l) for l in r.text.splitlines() if l.strip()]
    assert "".join(x["message"]["content"] for x in rows) == "1. Blatt holen" and rows[-1]["done"] is True
    assert "alt=sse" in seen["url"] and "streamGenerateContent" in seen["url"]
    body = seen["body"]
    assert body["systemInstruction"]["parts"][0]["text"] == "Du bist Coach."
    assert [c["role"] for c in body["contents"]] == ["user", "model", "user"]
    assert body["contents"][0]["parts"][1]["inlineData"]["mimeType"] == "image/png"


def test_chat_error_is_readable():
    fake_gemini(lambda request: httpx.Response(429, json={"error": {"message": "quota"}}))
    r = client.post("/api/chat", json={"messages": [{"role": "user", "content": "Hi"}]})
    assert r.status_code == 429 and "Limit" in r.json()["detail"]


def test_other_hosts_are_blocked():
    assert TestClient(main.app, base_url="http://evil.example").get("/api/health").status_code == 400


def test_no_cors_for_other_websites():
    r = client.options("/api/chat", headers={"Origin": "http://evil.example", "Access-Control-Request-Method": "POST"})
    assert "access-control-allow-origin" not in r.headers


def test_app_is_served():
    r = client.get("/")
    assert r.status_code == 200 and "LockedIn" in r.text
