# LockedIn Body

Eine Aufgaben-App, die auf deinen Körper hört. Du machst morgens einen kurzen Check (Schlaf, Ernährung, Alkohol usw.) und trägst dein Training ein. Ein internes Punktesystem rechnet daraus deinen Tageszustand, lässt ihn als Musik hören und bewertet jede Aufgabe: Gute Idee, Machbar, Lieber klein anfangen oder Heute eher nicht. To-dos kannst du einsprechen. Google Gemini versteht die Sprache, begründet die Bewertungen und hilft beim Anfangen.

## Starten (5 Minuten)

1. **API-Key holen:** https://aistudio.google.com/apikey, dort „Create API key“ (kostenlos möglich).
2. **App starten:** Doppelklick auf `start.bat` (Windows) oder im Terminal `./start.sh` (Mac/Linux). Python 3.9+ muss installiert sein.
3. **Key eintragen:** Beim ersten Start legt das Skript die Datei `backend/.env` an. Öffne sie, schreib deinen Key hinter `GEMINI_API_KEY=` (ohne Anführungszeichen), speichere und starte das Skript neu.
4. Der Browser öffnet http://localhost:8000. Unter Einstellungen > „Verbindung testen“ siehst du, ob alles bereit ist.

**Wichtig:** Öffne die App immer über http://localhost:8000, nicht per Doppelklick auf `index.html`. Nur so kann sie mit dem Backend reden.

Ohne Key läuft die App trotzdem: Bewertung und Sprachverständnis nutzen dann lokale Regeln. Es fehlen nur die Gemini-Begründungen, das bessere Sprachverständnis und die Starthilfe.

## Sicherheit und Datenschutz

- Der Key steht nur in `backend/.env` und wird nie an den Browser geschickt. Die Datei ist in `.gitignore`. Lade sie nicht hoch und poste den Key nirgends. Falls doch: auf aistudio.google.com/apikey löschen und neu erstellen.
- Das Backend nimmt nur Anfragen von localhost an und hat kein CORS, andere Webseiten in deinem Browser können dein Kontingent also nicht verbrauchen. Gib den Port nicht im Internet frei.
- Was an Google geht: dein gesprochener oder getippter To-do-Text, Aufgabentitel mit Dauer, dein Tageszustand in Kurzform (Verdict, Scores, Hauptgründe wie „wenig Schlaf“) und Chat-Nachrichten der Starthilfe. Der Rest (Check-ins, Training, Verlauf) bleibt im Browser (localStorage).
- Bei kostenlosen Gemini-Keys dürfen Eingaben laut Googles Bedingungen eventuell zur Produktverbesserung genutzt werden. Lies die aktuellen Bedingungen, bevor du sensible Dinge eingibst, oder nutze einen Key mit Abrechnung.
- Die Spracherkennung selbst nutzt die eingebaute Funktion von Chrome oder Edge. Dabei schickt der Browser die Aufnahme an seinen Anbieter. Tippen geht in jedem Browser.

## So hängt alles zusammen

```
Browser (frontend/index.html)  <->  Backend (backend/main.py)  <->  Gemini API
Aufgaben, Körper-Tab, Sound,        liefert die App aus, hält       Google
Spracherkennung, Punktesystem       den Key, prüft jede Antwort
```

Das Punktesystem bleibt immer der Chef: Gemini darf eine Stufe höchstens um eins verschieben und formuliert nur die Begründung. Alle Antworten werden im Backend geprüft (Datum, Dauer, Kategorie, Art), bevor sie in der App landen.

## Was wo ist

| Bereich | Wo |
|---|---|
| Stapel, Aufgaben, Kalender, XP, Bildschirmzeit | Tabs oben (aus LockedIn) |
| Morgen-Check, Training, Profil, Demos, Sound, Verlauf | Tab „Körper“ |
| Aufgabe einsprechen | Mikro-Knopf oben rechts |
| Zustand auf einen Blick | Leiste unter dem XP-Balken |
| Punkte sehen | Körper-Tab, Haken bei „Punkte anzeigen“ |
| Gemini-Begründungen | Tab „Aufgaben“, Knopf „Mit Gemini begründen lassen“ |

## Einstellungen

In `backend/.env` (oder als Umgebungsvariablen):

| Name | Bedeutung |
|---|---|
| `GEMINI_API_KEY` | dein Key (Pflicht für die KI) |
| `GEMINI_MODEL` | Standardmodell, vorgegeben `gemini-3.6-flash`. Schneller und mit mehr Gratis-Spielraum: `gemini-3.5-flash-lite` |
| `GEMINI_TIMEOUT` | Wartezeit auf Gemini in Sekunden (60) |
| `PORT`, `NO_BROWSER` | Port der App, kein automatisches Öffnen des Browsers |

Das Modell kannst du auch in der App unter Einstellungen > Modellname ändern. Wenn ein Modellname nicht existiert, sagt dir „Verbindung testen“, welche Flash-Modelle dein Key kennt.

## API des Backends

| Endpunkt | Macht |
|---|---|
| `GET /api/health` | Ist der Key gesetzt und gültig, gibt es das Modell? |
| `POST /api/voice-todo` | Gesprochenen Text in To-dos zerlegen (Titel, Dauer, Kategorie, Datum, Uhrzeit, Anstrengung, Art) |
| `POST /api/evaluate` | Begründung pro Aufgabe passend zum Zustand |
| `POST /api/chat` | Starthilfe-Chat, gestreamt |

## Selbst ändern

Datei öffnen, mit Strg+F suchen, ändern, speichern, im Browser F5 (Python-Dateien: Skript neu starten).

| Was | Datei | Suchbegriff |
|---|---|---|
| Abzüge für Schlaf, Nährstoffe, Alkohol | `frontend/index.html` | `sleepPen`, `nutPen`, `alcPen` |
| Texte für den Tageszustand | `frontend/index.html` | `function verdict` |
| Wie Aufgaben bewertet werden | `frontend/index.html` | `function capOf`, `function evalTask` |
| Woran Kopf-, Kraft- und Ausdaueraufgaben erkannt werden | `frontend/index.html` | `const KR=` |
| Sound | `frontend/index.html` | `MOODS`, `function kMood` |
| Was Gemini gesagt bekommt | `backend/main.py` | `voice_prompt`, `EVAL_PROMPT` |

## Tests

```
cd backend
pip install -r requirements-dev.txt
python -m pytest -q
```
Die Tests nutzen eine gefälschte Gemini-API. Du brauchst dafür weder Key noch Internet.

## Wenn etwas nicht klappt

| Meldung | Lösung |
|---|---|
| „Der API-Key fehlt“ | Key in `backend/.env` eintragen, Skript neu starten |
| „Google hat den API-Key abgelehnt“ | Key falsch kopiert (Leerzeichen?) oder gelöscht, neu erstellen |
| „Das Limit von Gemini ist gerade erreicht“ | Eine Minute warten oder `gemini-3.5-flash-lite` nehmen |
| „Das Modell … gibt es nicht“ | Einstellungen > Verbindung testen, dort steht ein passender Name |
| „Backend nicht erreichbar“ | Läuft `start.bat` bzw. `start.sh`? App über http://localhost:8000 öffnen |
| Mikro tut nichts | Chrome oder Edge nutzen, Mikrofon über das Schloss-Symbol erlauben |

Das Punktesystem ist stark vereinfacht und kein medizinischer Rat.
